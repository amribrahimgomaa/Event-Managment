// Select all slider wrappers
let sliderWrappers = document.querySelectorAll('.slider-wrapper');

// Loop through each slider wrapper
sliderWrappers.forEach((sliderWrapper, index) => {
    // Select slider and images within the current slider wrapper
    let slider = sliderWrapper.querySelector('.slider');
    let images = sliderWrapper.querySelectorAll('.slider img');
    let prevBtn = sliderWrapper.querySelector('.prev-btn');
    let nextBtn = sliderWrapper.querySelector('.next-btn');
    let currentIndex = 0;

    // Function to move to the next slide
    function nextSlide() {
        currentIndex++;
        if (currentIndex >= images.length) {
            currentIndex = 0;
        }
        updateSlider();
    }

    // Function to move to the previous slide
    function prevSlide() {
        currentIndex--;
        if (currentIndex < 0) {
            currentIndex = images.length - 1;
        }
        updateSlider();
    }

    // Function to update the slider position
    function updateSlider() {
        let position = -currentIndex * images[0].offsetWidth;
        slider.style.transform = `translateX(${position}px)`;
    }

    // Event listeners for the previous and next buttons
    prevBtn.addEventListener('click', prevSlide);
    nextBtn.addEventListener('click', nextSlide);

    // Automatically move to the next slide every 3 seconds
    setInterval(nextSlide, 3000);
});
